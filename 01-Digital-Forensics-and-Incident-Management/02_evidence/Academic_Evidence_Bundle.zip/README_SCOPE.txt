Partial Evidence Bundle (Redacted) — Academic Use
=================================================

This ZIP contains:
1) Redacted document artefacts suitable for academic demonstration.
2) An evidence_index.xlsx listing image/screenshot artefacts that require manual redaction
   (or exclusion) before any public publication.

Redaction Standard:
- UK GDPR data minimisation (remove direct identifiers)
- Remove/avoid publishing content that could enable harm, re-identification, or misuse.

Important:
- Images are NOT included in this bundle unless they have been manually redacted and verified.
- Use the evidence_index.xlsx to guide which images to redact, keep, or exclude.
